package hn.uth.contactoxtra.ui;

public interface OnItemClickListener<T> {
    void onItemClick(T data);
}
